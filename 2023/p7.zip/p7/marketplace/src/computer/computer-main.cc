#include "computer.h"

int main()
{
    return 0;
}