#include "seller.h"

int main()
{
    return 0;
}