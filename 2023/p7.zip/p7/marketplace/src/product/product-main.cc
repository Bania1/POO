#include <string>
#include <iostream>
#include "product.h"

int main()
{
    return 0;
}